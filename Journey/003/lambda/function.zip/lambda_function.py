import boto3
from PIL import Image, ImageFilter
import requests
import io

s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')

def lambda_handler(event, context):
    get_context = event["getObjectContext"]
    route = get_context["outputRoute"]
    token = get_context["outputToken"]
    s3_url = get_context["inputS3Url"]

    # Download the original image from S3
    image_request = requests.get(s3_url)
    image = Image.open(io.BytesIO(image_request.content))

    # Detect faces in the image using Amazon Rekognition
    response = rekognition.detect_faces(Image={'Bytes': image_request.content})
    faces = response['FaceDetails']
    
    # Blur out the faces in the image
    for face in faces:
        box = face['BoundingBox']
        x1 = int(box['Left'] * image.width)
        y1 = int(box['Top'] * image.height)
        x2 = int((box['Left'] + box['Width']) * image.width)
        y2 = int((box['Top'] + box['Height']) * image.height)
        face_image = image.crop((x1, y1, x2, y2))
        blurred_face = face_image.filter(ImageFilter.BoxBlur(radius=10))
        image.paste(blurred_face, (x1, y1, x2, y2))

    
    # Save the resulting image to memory
    output = io.BytesIO()
    image.save(output, format=image.format)
    output_content = output.getvalue()

    # Save the image and return the object response
    s3 = boto3.client('s3')
    s3.write_get_object_response(Body=output_content, RequestRoute=route, RequestToken=token)

    return {
        'statusCode': 200
    }